# Copyright (C) 2005, 2006 Jacques de Hooge, Geatec Engineering
#
# This program is free software.
# You can use, redistribute and/or modify it, but only under the terms stated in the QQuickLicence.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY, without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
# See the QQuickLicence for details.

import kivy
kivy.require('1.8.0') # replace with your current kivy version !

from kivy.app import App
from kivy.uix.widget import Widget
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.textinput import TextInput
from kivy.uix.gridlayout import GridLayout
from kivy.uix.relativelayout import RelativeLayout
from kivy.uix.treeview import TreeView as KivyTreeView, TreeViewNode

from eden.edenLib.node import *
from eden.edenLib.store import *

class ViewBase:
	def __init__ (self, enabledNode = None):
		self.enabledNode = getNode (enabledNode)
		self.mouseInside = False
		self.oldMouseInside = self.mouseInside
		self.containsFocus = False
		
	focused = property (lambda self: self.widget.focus)
	
	def createWidget (self):
		self.bareCreateWidget ()
	
		def bareWriteEnabled ():
			self.widget.disabled = not self.enabledNode.new
	
		if self.enabledNode:
			self.enabledLink = Link (self.enabledNode, None, bareWriteEnabled)
			self.enabledLink.write ()
	
		self.register_event_type ('onEnter')
		self.register_event_type ('onLeave')
		
		def mouseMove (*args):
			self.mousePosition = args [1]
			self.mouseInside = self.collide_point (*self.mousePosition)
			
			if self.mouseInside != self.oldMouseInside:
			
			if inside:
				self.dispatch ('onEnter')
			else:
				self.dispatch ('onLeave')
			
			self.oldMouseInside = self.mouseInside
	
		self.widget.bind (mouse_pos = mouseMove)		
	
		def enter (*args):
			self.containsFocus = True

			if self.widget.focus:
				application.focusedView = self
	
		self.widget.bind (onEnter = enter)
		
		def leave (*args):
			self.containsFocus = False
			
			if application.focusedView == self:
				application.focusedView = None
			
		self.widget.bind (onLeave = leave)
		
		return self.widget
		
	def focus (self):
		self.widget.focus = True

#	def select (self):	# ... Obsolete?
#		self.widget.select = True

class EmptyView (ViewBase):
	def bareCreateWidget (self):
		self.widget = Label (text = 'Empty')
		
	def adaptFontSize (self):
		pass

class LabelView (ViewBase):
	def __init__ (self, captionNode = None):
		self.captionNode = getNode (captionNode)
		
	def setText (self, text):
		self.widget.text = str (text)
		
	def bareCreateWidget (self):
		self.widget = Label ()
		
		if self.captionNode:
			self.link = Link (self.captionNode, None, lambda: self.setText (self.captionNode.new))
			self.link.write ()
		
	def adaptFontSize (self):
		self.widget.font_size = self.widget.height / 1.5

class ButtonView (ViewBase):
	def __init__ (self, actionNode = None, captionNode = None):
		self.actionNode = getNode (actionNode)
		self.captionNode = getNode (captionNode)

	def setText (self, text):
		self.widget.text = str (text)
		
	def bareCreateWidget (self):
		self.widget = Button ()
		
		if self.actionNode:
			self.actionLink = Link (self.actionNode, lambda params: self.actionNode.change (None, True), None)
			self.widget.on_press = self.actionLink.read
		
		if self.captionNode:
			self.captionLink = Link (self.captionNode, None, lambda: self.setText (self.captionNode.new))
			self.captionLink.write ()		
		
	def adaptFontSize (self):
		self.widget.font_size = self.widget.height / 1.5 
		
class TextView (ViewBase):
	def __init__ (self, valueNode = None):
		self.valueNode = getNode (valueNode)
		
	def setText (self, text):
		self.widget.text = str (text)
		
	def bareCreateWidget (self):
		self.widget = TextInput ()
		
		if self.valueNode:
			self.link = Link (self.valueNode, lambda params: self.valueNode.change (str (self.widget.Text)), lambda: self.setText (self.valueNode.new))
			self.link.write ()		
		
	def adaptFontSize (self):
		pass
		
# <tree> = [<branch>, ...]
# <branch> = <item> | (<item>, <tree>)
		
class TreeView (ViewBase):	# Views a <tree>

	# --- Constructor and widget creation method, like supported by all views
	
	def __init__ (
		self,
		treeNode,
		selectedPathNode = None,
		enabled = None,
		contextMenuView = None,
		transformer = None,
		expansionLevel = None,
		dragObjectGetter = None,
		dragResultGetter = None,
		dropResultGetter = None,
		dropActionGetter = None,
		hoverPathNode = None,
		hintGetter = None,
		tweaker = None
	):
		EnabledViewMix.__init__ (self, enabled)
		FocusViewMix.__init__ (self)	
	
		self.treeNode = self.getNode (treeNode)
		self.selectedPathNode = self.getNode (selectedPathNode)
		self.contextMenuView = contextMenuView
		self.transformer = transformer
		self.expansionLevelNode = getNode (expansionLevel)
		self.dragObjectGetter = dragObjectGetter
		self.dragResultGetter = dragResultGetter
		self.dropResultGetter = dropResultGetter
		self.dropActionGetter = dropActionGetter
		self.hoverPathNode = getNode (hoverPathNode)
		self.hintGetter = hintGetter
		self.tweaker = tweaker
		self.stretchHeight = True
				
	def bareCreateWidget (self):
		self.widget = KivyTreeView ()	
		#self.widget.HideSelection = False
		#self.widget.AllowDrop = True

		self.visibleTreeNode = Node ([])
		
		if self.expansionLevelNode:
			self.visibleTreeNode.dependsOn ([self.treeNode, self.expansionLevelNode], lambda: None)
		else:
			self.visibleTreeNode.dependsOn ([self.treeNode], lambda: None)
	
		self.visibleTreeLink = Link (self.visibleTreeNode, None, lambda: self.bareWrite ()) 
		self.visibleTreeLink.write ()			

		self.interestingPathsNode = Node ([])
		self.interestingPathsNode.dependsOn ([self.treeNode], lambda: self.interestingPaths ())

		if self.selectedPathNode:
			if not hasattr (self.selectedPathNode, 'getter'):
				self.selectedPathNode.dependsOn ([self.interestingPathsNode], lambda: self.interestingPathsNode.new [0])
				
			self.selectedPathLink = Link (self.selectedPathNode, lambda params: self.visibleTreeLink.writing or self.selectedPathNode.change (self.pathFromTreeViewNode (self.widget.get_node_at_pos (params [1] .Location))), self.bareWriteSelectedPath)
			# Leave self.selectedPathLink.writeBack == True to properly deal with rightclicks. Probably bug in WinForms, because not needed with ListView.
			self.widget.bind (mouse_pos = self.selectedPathLink.read)		# This is the only event already occurring at mouse down, so before a drag
		
		self.visiblePathNode = Node ([])			
		self.visiblePathNode.dependsOn ([self.interestingPathsNode], lambda: self.interestingPathsNode.new [1])
		self.visiblePathLink = Link (self.visiblePathNode, None, lambda: self.treeViewNodeFromPath (self.visiblePathNode.new) .EnsureVisible ())				
		
		if self.contextMenuView:
			self.widget.ContextMenuStrip = self.contextMenuView.createWidget ()
			self.widget.MouseUp += lambda sender, event: event.Button != Forms.MouseButtons.Right or sender.ContextMenuStrip.Show (sender, event.Location)
					
		if self.dropActionGetter:
			self.dragLink = Link (self.treeNode, lambda params: self.treeNode.change (self.dragResultGetter ()), None)
			self.dropLink = Link (self.treeNode, lambda params: self.treeNode.change (self.dropResultGetter (params [0], params [1])), None)
			
#			self.widget.ItemDrag += self.itemDrag
#			self.widget.DragEnter += self.dragEnter
#			self.widget.DragOver += self.dragOver
#			self.widget.DragLeave += self.dragLeave
#			self.widget.DragDrop += self.dragDrop
			
#		self.toolTip = Forms.ToolTip ()
#		self.toolTip.ShowAlways = True
		self.hoverTreeViewNode = None
#		self.widget.MouseMove += self.track

		tweak (self)

	# --- Low level read methods to be passed to Links
	
	# None here, all coded as lambdas
	
	# --- Low level write methods to be passed to Links
	
	def bareWriteSelectedPath (self):	# Assignment can't be directly replaced by a lambda
		self.widget.SelectedNode = self.treeViewNodeFromPath (self.selectedPathNode.new)
				
	def bareWrite (self):
		expansionDictionary = {}
		self.fillExpansionDictionary ((), expansionDictionary)
		self.clearTree ()
		self.writeTree (self.treeNode.new, None, (), expansionDictionary)
		
	def clearTree (self):
        for treeViewNode in list (self.widget.iterate_all_nodes ())
            self.widget.remove_node (treeVieuNode)	
		
	def writeTree (self, tree, parentWidgetNode, hashPath, expansionDictionary):
		for branch in tree:
			widgetNode = Forms.TreeViewLabel ()
			
			if branch.__class__ == tuple:
				item = branch [0]
				itemText = str (item)
				
				if self.transformer:
					newHashPath = hashPath + (item, )
				else:
					newHashPath = hashPath + (itemText, )
									
				self.writeTree (branch [1], widgetNode, newHashPath, expansionDictionary)
			else:
				item = branch
				itemText = str (item)
				
				if self.transformer:
					newHashPath = hashPath + (item, )
				else:
					newHashPath = hashPath + (itemText, )
			
			if self.transformer:
				widgetNode.Tag = item
				
				bugFix = self.transformer (item)
				widgetNode.Text = bugFix
			else:
				widgetNode.Text = itemText
					
			try:
				if self.expansionLevelNode:
					if self.expansionLevelNode.new > len (hashPath) + 1:
						if not widgetNode.is_open:
							self.widget.toggle_node (widgetNode)
				elif expansionDictionary [newHashPath]:
					if not widgetNode.is_open:
						self.widget.toggle_node (widgetNode)
			except KeyError:
				pass
			
			self.widget.add_node (widgetNode, parentNode)				
	# --- Drag and drop support methods
	
	def setTargetTreeViewNode (self, event):
		# From the combination (self.targetTreeViewNode, self.targetValid, self.onTarget) the insertion location can be deduced:
		# - (<anItem>, True, False) means: insert below underlined node
		# - (<anItem>, True, True) means: insert into highLighted node
		# - (None, True, False) means: insert above top node
		# - (None, False, False) means: invalid insertion location
		
		try:
			topTreeViewNode = self.widget.TopNode
			
			mousePoint = self.widget.PointToClient (Drawing.Point (event.X, event.Y))						# Normalized mouse cursor
			targetPoint = Drawing.Point (mousePoint.X, mousePoint.Y + topTreeViewNode.Bounds.Height / 4)	# Node above rather than under mouse cursor
			
			self.targetTreeViewNode = self.widget.GetNodeAt (targetPoint.X, targetPoint.Y)
			self.targetValid = True																			# Even when targetTreeViewNode is None
			
			# Selection area is is symetric around targetPoint
			# On target area should cover exactly half the selection area
			# First assume targetPoint == mousePoint, derive selection area and from that the on target area
			# Then translate both area's over targetPoint.y - mousePoint.y
			self.onTarget = self.targetValid and self.targetTreeViewNode.Bounds.Top + topTreeViewNode.Bounds.Height / 4 < mousePoint.Y < self.targetTreeViewNode.Bounds.Bottom - topTreeViewNode.Bounds.Height / 4
		except AttributeError:	# topTreeViewNode is None or self.targetTreeViewNode is None, None doesn't have Bounds attribute
			self.targetTreeViewNode = None
			self.onTarget = False

			if self.treeNode.new == []:
				self.targetValid = True
			else:
				self.fillLastExpandedTreeViewNode ()
				self.targetValid = self.lastExpandedTreeViewNode.Bounds.Bottom < self.widget.ClientSize.Height - 1
				
	def drawTargetLine (self, appear):
		try:
			if self.onTarget:
				if appear:
					self.oldForeColor = self.targetTreeViewNode.ForeColor
					self.oldBackColor = self.targetTreeViewNode.BackColor

					self.targetTreeViewNode.ForeColor = Drawing.SystemColors.HighlightText
					self.targetTreeViewNode.BackColor = Drawing.SystemColors.Highlight
				else:
					self.targetTreeViewNode.ForeColor = self.oldForeColor
					self.targetTreeViewNode.BackColor = self.oldBackColor	
			elif self.targetValid:
				color = ifExpr (appear, Drawing.Color.Blue, Drawing.Color.White)
				
				if self.targetTreeViewNode:
					self.widget.CreateGraphics () .DrawLine (Drawing.Pen (color, 1), self.targetTreeViewNode.Bounds.Left, self.targetTreeViewNode.Bounds.Top, self.targetTreeViewNode.Bounds.Right, self.targetTreeViewNode.Bounds.Top)
				elif self.treeNode.new != []:
					self.widget.CreateGraphics () .DrawLine (Drawing.Pen (color, 1), 0, self.lastExpandedTreeViewNode.Bounds.Bottom, self.widget.ClientSize.Width, self.lastExpandedTreeViewNode.Bounds.Bottom)
		except:
			pass
				
	def itemDrag (self, sender, event):
		self.widget.Focus ()
	
		dragObject.sourceView = self
		dragObject.value = self.dragObjectGetter ()
	
		if self.widget.DoDragDrop (str (dragObject.value), Forms.DragDropEffects.Move | Forms.DragDropEffects.Copy) != Forms.DragDropEffects.None:
			self.dragLink.read ()
		
		dragObject.clear ()
				
	def dragDrop (self, sender, event):
		self.widget.HideSelection = False
		self.widget.Focus ()
		
		self.drawTargetLine (False)

		dragObject.keyState = event.KeyState	# Don't use directly, use dragObject.modifiers property instead		
		dragObject.dropAction = self.dropActionGetter ()
		
		if dragObject.dropAction and self.targetValid:
			try:		
				if self.targetTreeViewNode:
					self.dropLink.read (self.pathFromTreeViewNode (self.targetTreeViewNode), not self.onTarget)
				else:
					self.dropLink.read ([], False)
			except Refusal, refusal:
				handleNotification (refusal) 
				event.Effect = Forms.DragDropEffects.None
		
		if dragObject.imported:
			dragObject.clear ()
				
	def dragEnter (self, sender, event):
		self.widget.HideSelection = True
		
		event.Effect = event.AllowedEffect
		
		self.targetTreeViewNode = None	
		self.targetValid = False
		
		if dragObject.imported:
			text = event.Data.GetData (Forms.DataFormats.Text)
			
			try:
				dragObject.value = eval (text)
			except:
				dragObject.value = text
			
		dragObject.targetView = self
		
	def dragOver (self, sender, event):
		self.drawTargetLine (False)
		
		dragObject.keyState = event.KeyState	# Don't use directly, use dragObject.modifiers property instead		
		dropAction = self.dropActionGetter ()
	
		if dropAction:						
			self.setTargetTreeViewNode (event)

			event.Effect = ifExpr (self.targetValid,
				ifExpr (dropAction == DropActions.Move,
					Forms.DragDropEffects.Move,
					Forms.DragDropEffects.Copy),
				Forms.DragDropEffects.None)
			
			self.drawTargetLine (True)
							
		else:
			event.Effect = Forms.DragDropEffects.None
										
	def dragLeave (self, sender, event):
		self.widget.HideSelection = False
		
		self.drawTargetLine (False)
		
		if dragObject.imported:
			dragObject.clear ()
			
		dragObject.targetView = None

	# --- Miscellaneous methods
	
	def track (self, sender, event):
		hoverTreeViewNode = self.widget.GetNodeAt (event.Location)
		if not hoverTreeViewNode is self.hoverTreeViewNode:
			self.hoverTreeViewNode = hoverTreeViewNode
			
			if self.hoverPathNode:
				self.hoverPathNode.change (self.pathFromTreeViewNode (self.hoverTreeViewNode))
				
			self.toolTip.Active = False
			
			if self.hintGetter and self.hoverTreeViewNode:
				self.toolTip.SetToolTip (self.widget, getHint (self.hintGetter))
				self.toolTip.Active = True
	
	def assignSelectedTreeViewNode (self, treeViewNode):
		self.widget.SelectedNode = treeViewNode		
				
	def itemFromTreeViewNode (self, treeViewNode):
		if not treeViewNode:
			return None
		
		rootBranch  = self.treeNode.new [0]
		
		if self.transformer:
			return treeViewNode.Tag
		elif rootBranch.__class__ == tuple:
			return getAsTarget (treeViewNode.Text, rootBranch [0] .__class__)
		else:
			return getAsTarget (treeViewNode.Text, rootBranch.__class__)
			
	def pathFromTreeViewNode (self, treeViewNode):
		path = []
		while not treeViewNode is None:
			path.insert (0, self.itemFromTreeViewNode (treeViewNode))
			treeViewNode = treeViewNode.parentNode
			
		return path
	
	def treeViewNodeFromPath (self, path):
		treeViewNodes = self.widget.Nodes
		treeViewNode = None						# ... Added y06m05d08
		
		for item in path:
			for treeViewNode in treeViewNodes:
				candidateItem = self.itemFromTreeViewNode (treeViewNode)
				
				if candidateItem == item:
					treeViewNodes = treeViewNode.Nodes
					break
					
		return treeViewNode		
		
	def interestingPaths (self):
		selectedPath = []
		visiblePath = []
		self.fillInterestingPaths (self.treeNode.new, self.treeNode.old, selectedPath, visiblePath, [True])
		return (selectedPath, visiblePath)

	def fillInterestingPaths (self, newTree, oldTree, selectedPath, visiblePath, select):
		newIndex = len (newTree) - 1
		oldIndex = len (oldTree) - 1
		
		growth = newIndex - oldIndex
		
		while newIndex >= 0 and oldIndex >= 0:
			newBranch = tupleFromBranch (newTree [newIndex])
			oldBranch = tupleFromBranch (oldTree [oldIndex])
			
			if newBranch [0] == oldBranch [0]:
				if self.fillInterestingPaths (newBranch [1], oldBranch [1], selectedPath, visiblePath, select):
					if select [0]:
						selectedPath.insert (0, newBranch [0])
					visiblePath.insert (0, newBranch [0])
					return True
			else:
				if growth <= 0:
					selectedPath.insert (0, newBranch [0])
				visiblePath.insert (0, newBranch [0])
				return True
			
			newIndex -= 1
			oldIndex -= 1
			
		if newIndex >= 0:
			visiblePath.insert (0, tupleFromBranch (newTree [newIndex]) [0])
			return True
		
		if oldIndex >= 0:
			select [0] = False
			return True
			
		return False		
	
	def fillExpansionDictionary (self, hashPath, expansionDictionary):
        for treeViewNode in list (self.widget.iterate_all_nodes ()):
			if self.transformer:
				newHashPath = hashPath + (treeViewNode.tag, )
			else:
				newHashPath = hashPath + (treeViewNode.text, )	# Store as string since its used in View rather than Node
				
			expansionDictionary [newHashPath] = treeViewNode.is_open
			
	def fillLastExpandedTreeViewNode (self):
		currentTreeViewNode = None	# Virtual parent of root(s)
		expanded = True				# Always expanded	
		treeViewNodes = self.widget.Nodes
		
		while expanded and len (treeViewNodes) > 0:
			currentTreeViewNode = treeViewNodes [len (treeViewNodes) - 1]
			expanded = currentTreeViewNode.IsExpanded
			treeViewNodes = currentTreeViewNode.Nodes
			
		self.lastExpandedTreeViewNode = currentTreeViewNode
	
class SpanLayout (RelativeLayout):
	def __init__ (self):
		RelativeLayout.__init__ (self)
		self.taggedWidgets = []
		self.nrOfRows = 0
		self.nrOfColumns = 0

	def addChildWidget (self, childWidget, rowIndex, rowSpan, columnIndex, columnSpan, view):
		self.add_widget (childWidget)
		self.taggedWidgets.append ((childWidget, rowIndex, rowSpan, columnIndex, columnSpan, view))
		self.nrOfRows = max (self.nrOfRows, rowIndex + rowSpan)
		self.nrOfColumns = max (self.nrOfColumns, columnIndex + columnSpan)
		
	def do_layout (self, *args):
		rowHeight = self.height / self.nrOfRows
		columnWidth = self.width / self.nrOfColumns
		
		for taggedWidget in self.taggedWidgets:
			taggedWidget [0] .y = self.height - (taggedWidget [1] + taggedWidget [2]) * rowHeight
			taggedWidget [0] .height = taggedWidget [2] * rowHeight
			taggedWidget [0] .x = taggedWidget [3] * columnWidth
			taggedWidget [0] .width = taggedWidget [4] * columnWidth
			taggedWidget [5] .adaptFontSize ()
		
class GridView (ViewBase):
	def __init__ (self, childViews):
		self.rows = []
		for rowOrWeight in childViews:
			if isinstance (rowOrWeight, int):
				self.rows [-1][1] = rowOrWeight
			elif rowOrWeight:
				self.rows.append ([[], 1])
				for viewOrSpan in rowOrWeight:
					if isinstance (viewOrSpan, int):
						self.rows [-1][0][-1][1] = viewOrSpan				
					elif viewOrSpan:
						self.rows [-1][0] .append ([viewOrSpan, 1])
					else:
						self.rows [-1][0] .append ([EmptyView (), 1])
			else:
				self.rows.append ([[[EmptyView (), 1]], 0])
						
	def bareCreateWidget (self):
		self.widget = SpanLayout ()
		
		self.nrOfRowCells = 0
		self.nrOfColumnCells = 0
		rowIndex = 0
		for row in self.rows:
			columnIndex = 0
			for element in row [0]:
				self.widget.addChildWidget (element [0] .createWidget (), rowIndex, row [1], columnIndex, element [1], element [0])
				columnIndex += element [1]
				self.nrOfColumnCells = max (self.nrOfColumnCells, columnIndex)
				
			rowIndex += row [1]
				
			if row [1]:
				self.nrOfRowCells += rowIndex
				self.stretch = True
			else:
				# self.nrOfRowCells += 1
				self.nrOfRowCells += rowIndex
		
class HGridView (GridView):
	def __init__ (self, childViews):
		GridView.__init__ (self, [childViews])
		
class VGridView (GridView):
	def __init__ (self, childViews):
		weightedRows = []
		for viewOrWeight in childViews:
			if isinstance (viewOrWeight, ViewBase):		
				weightedRows.append ([viewOrWeight])
			elif viewOrWeight == None:
				weightedRows.append ([])
			else:
				weightedRows.append (viewOrWeight)
		GridView.__init__ (self, weightedRows)
		
class MainView (App, ViewBase):
	def __init__ (
		self,
		clientView = None,
		captionNode = '',
	):
		App.__init__ (self)
		self.clientView = clientView
		application.mainView = self
	
	def bareCreateWidget (self):
		self.widget = RelativeLayout ()
		self.widget.add_widget (self.clientView.createWidget ())
		
	def build (self):
		return self.createWidget ()
		
	def execute (self):
		self.run ()

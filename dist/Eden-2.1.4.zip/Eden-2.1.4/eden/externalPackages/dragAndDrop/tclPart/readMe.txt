Source: http://sourceforge.net/projects/tkdnd/
Installation: Copy directory tkdnd2.6 to the tcl subdirectory of your Python installation.
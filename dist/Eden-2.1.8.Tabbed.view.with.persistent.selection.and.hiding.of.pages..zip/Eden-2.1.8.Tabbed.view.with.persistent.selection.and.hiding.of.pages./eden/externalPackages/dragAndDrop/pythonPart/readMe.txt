Source: http://sourceforge.net/projects/tkinterdnd/
Installation: Copy directory TkinterDnD2 to the site-packages subdirectory of your Python installation.